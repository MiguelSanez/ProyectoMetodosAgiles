
package Objeto_negocio;

public enum Estado {
    PENDIENTE, EN_PROGRESO, TERMINADA
}