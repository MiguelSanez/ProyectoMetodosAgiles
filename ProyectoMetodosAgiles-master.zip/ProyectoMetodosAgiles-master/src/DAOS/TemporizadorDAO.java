
package DAOS;

public class TemporizadorDAO {
    
}
