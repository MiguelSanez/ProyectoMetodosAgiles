
package DAOS;


import java.awt.Dimension;
import java.awt.Toolkit;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.KeyStroke;

public abstract class BaseDAO<T> {
    private Connection con;
    
    public Connection conectar() {
        String url = "jdbc:sqlite:src\\basededatos\\proyectopomodoro.db";
        try {

            System.out.println("Conectando a la base de datos");
            con = DriverManager.getConnection(url);
            if (con != null) {
                System.out.println("Conexion con exito!");
                return con;
            } else {
                System.out.println("Error: Con es invalido");
                return null;
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return con;
    }
    
    public abstract ArrayList<T> consultar() throws Exception;
    
    public abstract T consultarPorId(Integer id) throws Exception;
    
    public abstract void eliminar (Integer id) throws Exception;
    
    public abstract ArrayList<T> Buscar(String elemento) throws Exception;
    
    public static void success(String title, String msg) {
        JFrame jf = new JFrame();
        jf.setAlwaysOnTop(true);
        JOptionPane.showMessageDialog(jf, msg, title, JOptionPane.INFORMATION_MESSAGE);
    }

    public static void error(String title, String msg) {
        JFrame jf = new JFrame();
        jf.setAlwaysOnTop(true);
        JOptionPane.showMessageDialog(jf, msg, title, JOptionPane.ERROR_MESSAGE);
    }

    public static boolean question(String title, String message) {
        JFrame jf = new JFrame();
        jf.setAlwaysOnTop(true);
        int reply = JOptionPane.showConfirmDialog(jf, message, title, JOptionPane.YES_NO_OPTION);
        return reply == JOptionPane.YES_OPTION;
    }

    public static void centerFrame(Frame frame) {
        //Obtiene el tamaño de la pantalla
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

        // Obtiene el tamaño de la ventana de la aplicación
        Dimension frameSize = frame.getSize();

        // Se asegura que el tamaño de la ventana de la aplicación
        // no exceda el tamaño de la pantalla
        if (frameSize.height > screenSize.height) {
            frameSize.height = screenSize.height;
        }
        if (frameSize.width > screenSize.width) {
            frameSize.width = screenSize.width;
        }

        // Centra la ventana de la aplicación sobre la pantalla
        frame.setLocation((screenSize.width - frameSize.width) / 2,
                (screenSize.height - frameSize.height) / 2);
    }

    public static void centerFrame(JDialog frame) {
        //Obtiene el tamaño de la pantalla
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

        // Obtiene el tamaño de la ventana de la aplicación
        Dimension frameSize = frame.getSize();

        // Se asegura que el tamaño de la ventana de la aplicación
        // no exceda el tamaño de la pantalla
        if (frameSize.height > screenSize.height) {
            frameSize.height = screenSize.height;
        }
        if (frameSize.width > screenSize.width) {
            frameSize.width = screenSize.width;
        }

        // Centra la ventana de la aplicación sobre la pantalla
        frame.setLocation((screenSize.width - frameSize.width) / 2,
                (screenSize.height - frameSize.height) / 2);
    }

    public static boolean isNumeric(String str) {
        try {
            Double.parseDouble(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
