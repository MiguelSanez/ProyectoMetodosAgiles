
package DAOS;

import Objeto_negocio.Tarea;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class TareaDAO extends BaseDAO{
    
    private Tarea tarea;
    public boolean señal;

    public TareaDAO(Tarea tarea) {
        this.tarea = tarea;
    }
    
    public boolean save() {
        String sql = "INSERT INTO tareas(nombre,descripcion,estado) VALUES(?,?,?)";
        PreparedStatement ps;
        try {
            Connection conexion=this.conectar();
            ps = conexion.prepareStatement(sql);
            ps.setString(1, tarea.getNombre());
            ps.setString(2, tarea.getDescripcion());
            ps.setInt(3, 1);

            ps.executeUpdate();
            señal=true;

            System.out.println("Proceso ejecutado con exito");
            return true;

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return false;
    }
    
    public void actualizar(Tarea entidad) throws Exception {
        String sql = "UPDATE tareas SET nombre=?, descripcion=?, estado=? WHERE id=?";
         PreparedStatement ps;
         try {
            Connection conexion = conectar();
            ps = conexion.prepareStatement(sql);
            ps.setString(1, entidad.getNombre());
            ps.setString(2, entidad.getDescripcion());
            ps.setInt(3, entidad.getEstado().ordinal());

            ps.executeUpdate();
            ps.close();
            System.out.println("Proceso ejecutado con exito");

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    
    public boolean repetidoTitulo(String titulo){
        String sql = "select * from tareas where nombre =?";
        PreparedStatement ps;
        ResultSet rs;
        try {
            Connection conexion=this.conectar();
            ps = conexion.prepareStatement(sql);
            ps.setString(1, titulo);
            rs = ps.executeQuery();
            if(rs.next())return true;
            System.out.println("Proceso ejecutado con exito");
            señal=false;

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return false;
    }   
    
    public boolean repetidoDescripcion(String descripcion){
        String sql = "select * from tareas where descripcion =?";
        PreparedStatement ps;
        ResultSet rs;
        try {
            Connection conexion=this.conectar();
            ps = conexion.prepareStatement(sql);
            ps.setString(1, descripcion);
            rs = ps.executeQuery();
            if(rs.next())return true;
            System.out.println("Proceso ejecutado con exito");
            señal=false;

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return false;
    }  

    @Override
    public ArrayList consultar() throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Object consultarPorId(Integer id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void eliminar(Integer id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public ArrayList Buscar(String elemento) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
